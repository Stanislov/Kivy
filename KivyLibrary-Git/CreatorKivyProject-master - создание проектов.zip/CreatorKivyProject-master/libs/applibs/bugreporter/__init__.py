# -*- coding: utf-8 -*-

''' 
Разработано специально для проекта VKGroups -
https://github.com/HeaTTheatR/VKGroups

Copyright © 2016  Easy

Для предложений и вопросов:
<kivydevelopment@gmail.com>

Данный файл распространяется по услолвиям той же лицензии,
что и фреймворк Kivy.

'''

from . bugreporter import BugReporter


__version__ = '0.0.1'
