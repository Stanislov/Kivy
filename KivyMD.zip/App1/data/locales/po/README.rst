Example for an internationalized Kivy Application
=================================================

Note: _() dynamic changes works only in kv right now.

How to extract _() message and update the po::

    make po

How to generate the locales::

    make mo

