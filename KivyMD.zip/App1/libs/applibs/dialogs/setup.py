java:803)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:457)
	at io.netty.util.concurrent.SingleThreadEventExecutor$4.run(SingleThreadEventExecutor.java:989)
	at io.netty.util.internal.ThreadExecutorMap$2.run(ThreadExecutorMap.java:74)
	at io.netty.util.concurrent.FastThreadLocalRunnable.run(FastThreadLocalRunnable.java:30)
	at java.base@11.0.6/java.lang.Thread.run(Thread.java:834)

"PtyProcess Reaper for [/bin/bash, --rcfile, /home/stanislav/soft/pycharm/plugins/terminal/jediterm-bash.in, -i]" prio=0 tid=0x0 nid=0x0 runnable
     java.lang.Thread.State: RUNNABLE
 (in native)
	at com.sun.jna.Native.invokeInt(Native Method)
	at com.sun.jna.Function.invoke(Function.java:426)
	at com.sun.jna.Function.invoke(Function.java:361)
	at com.sun.jna.Library$Handler.invoke(Library.java:265)
	at com.sun.proxy.$Proxy100.waitpid(Unknown Source)
	at com.pty4j.unix.linux.OSFacadeImpl.waitpid(OSFacadeImpl.java:168)
	at com.pty4j.unix.Pty.wait0(Pty.java:256)
	at com.pty4j.unix.UnixPtyProcess.waitFor(UnixPtyProcess.java:337)
	at com.pty4j.unix.UnixPtyProcess$Reaper.run(UnixPtyProcess.java:407)

"process reaper" prio=0 tid=0x0 nid=0x0 runnable
     java.lang.Thread.State: RUNNABLE
 (in native)
	at java.base@11.0.6/java.lang.ProcessHandleImpl.waitForProcessExit0(Native Method)
	at java.base@11.0.6/java.lang.ProcessHandleImpl$1.run(ProcessHandleImpl.java:138)
	at java.base@11.0.6/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1128)
	at java.base@11.0.6/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:628)
	at java.base@11.0.6/java.lang.Thread.run(Thread.java:834)

"AWT-XAWT" prio=0 tid=0x0 nid=0x0 runnable
     java.lang.Thread.State: RUNNABLE
 (in native)
	at java.desktop@11.0.6/sun.awt.X11.XToolkit.waitForEvents(Native Method)
	at java.desktop@11.0.6/sun.awt.X11.XToolkit.run(XToolkit.java:689)
	at java.desktop@11.0.6/sun.awt.X11.XToolkit.run(XToolkit.java:653)
	at java.base@11.0.6/java.lang.Thread.run(Thread.java:834)

"JavaFX Application Thread" prio=0 tid=0x0 nid=0x0 runnable
     java.lang.Thread.State: RUNNABLE
 (in native)
	at platform/javafx.graphics@11.0.6/com.sun.glass.ui.gtk.GtkApplication._runLoop(Native Method)
	at platform/javafx.graphics@11.0.6/com.sun.glass.ui.gtk.GtkApplication.lambda$runLoop$11(GtkApplication.java:277)
	at platform/javafx.graphics@11.0.6/com.sun.glass.ui.gtk.GtkApplication$$Lambda$700/0x00000001007b8840.run(Unknown Source)
	at java.base@11.0.6/java.lang.Thread.run(Thread.java:834)

"Reference Handler" prio=0 tid=0x0 nid=0x0 runnable
     java.lang.Thread.State: RUNNABLE

	at java.base@11.0.6/java.lang.ref.Reference.waitForReferencePendingList(Native Method)
	at java.base@11.0.6/java.lang.ref.Reference.processPendingReferences(Reference.java:241)
	at java.base@11.0.6/java.lang.ref.Reference$ReferenceHandler.run(Reference.java:213)

"Signal Dispatcher" prio=0 tid=0x0 nid=0x0 runnable
     java.lang.Thread.State: RUNNABLE


"DestroyJavaVM" prio=0 tid=0x0 nid=0x0 runnable
     java.lang.Thread.State: RUNNABLE


"Indexing" prio=0 tid=0x0 nid=0x0 waiting on condition
     java.lang.Thread.State: WAITING
 on java.util.concurrent.locks.ReentrantReadWriteLock$NonfairSync@2c600f7d owned by "Indexing" Id=96
	at java.base@11.0.6/jdk.internal.misc.Unsafe.park(Native Method)
	at java.base@11.0.6/java.util.concurrent.locks.LockSupport.park(LockSupport.java:194)
	at java.base@11.0.6/java.util.concurrent.locks.AbstractQueuedSynchronizer.parkAndCheckInterrupt(AbstractQueuedSynchronizer.java:885)
	at java.base@11.0.6/java.util.concurrent.locks.AbstractQueuedSynchronizer.acquireQueued(AbstractQueuedSynchronizer.java:917)
	at java.base@11.0.6/java.util.concurrent.locks.AbstractQueuedSynchronizer.acquire(AbstractQueuedSynchronizer.java:1240)
	at java.base@11.0.6/java.util.concurrent.locks.ReentrantReadWriteLock$WriteLock.lock(ReentrantReadWriteLock.java:959)
	at com.intellij.util.indexing.impl.MapReduceIndex.updateWithMap(MapReduceIndex.java:355)
	at com.intellij.util.indexing.impl.MapReduceIndex.lambda$createIndexUpdateComputation$0(MapReduceIndex.java:247)
	at com.intellij.util.indexing.impl.MapReduceIndex$$Lambda$1765/0x0000000100fb2440.compute(Unknown Source)
	at com.intellij.util.indexing.StorageBufferingHandler.runUpdate(StorageBufferingHandler.java:30)
	at com.intellij.util.indexing.FileBasedIndexImpl.runIndexUpdate(FileBasedIndexImpl.java:1325)
	at com.intellij.util.indexing.FileBasedIndex