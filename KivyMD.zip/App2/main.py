from kivy.lang import Builder

from kivymd.app import MDApp


KV = """
Screen:

    MDToolbar:
        title: "My one app"
        elevation: 10
        md_bg_color: app.theme_cls.primary_color
        left_action_items: [["menu", lambda x: x]]
        pos_hint: {"top": 0.1}

    MDRaisedButton:
        text: "Hello task"
        pos_hint: {"center_x": .5, "center_y": .5}
    MDRaisedButton:
        text: "Hello peoples"
        pos_hint: {"center_x": .9, "center_y": .9}

        
"""


class HelloWorld(MDApp):
    def build(self):
        return Builder.load_string(KV)


HelloWorld().run()